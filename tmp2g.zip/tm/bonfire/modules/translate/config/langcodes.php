<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['translate']['codes']['google'] = array(
	'english'   => 'en',
	'spanish'   => 'es',
	'spanish_am'=> 'es',
    'french'    => 'fr',
    'hindi'     => 'hi',
    'italian'   => 'it',
    'persian'   => 'fa', 
    'portuguese' => 'pt',
    'portuguese_br' => 'pt',
    'russian'   => 'ru',
);