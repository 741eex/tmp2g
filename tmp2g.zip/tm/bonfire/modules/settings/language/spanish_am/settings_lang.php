<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['set_allow_name_change_note']	= '¡Permitir a los usuarios cambiar su nombre (diplay name) después de registrarse?';
$lang['set_name_change_frequency']	= ' cambiar cada';
$lang['set_days']					= ' días';
$lang['settings_saved_success']     = 'Su configuración fue guardada correctamente.';
$lang['settings_error_success']     = 'Hubo un error guardando su configuración.';


// $lang['set_tab_settings']			= 'Main Settings';
// $lang['set_tab_security']			= 'Security Settings';
// $lang['set_tab_developer']			= 'Developer Settings';
// 
// $lang['set_option_password']		= 'Password Options';
// $lang['set_option_developer']		= 'Developer Options';