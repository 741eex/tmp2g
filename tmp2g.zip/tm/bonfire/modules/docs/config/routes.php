<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$route['docs/search'] = 'docs/search';
$route['docs/(:any)'] = 'docs';