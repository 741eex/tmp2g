<?php defined('BASEPATH') || exit('No direct script access allowed');

$config['module_config'] = array(
    'description' => 'Helps maintain database versioning.',
    'author'      => 'Bonfire Team',
    'version'     => '0.7.3',
    'name'        => 'lang:bf_menu_migrations',
    'menu_topic'  => array(
        'developer' => 'lang:bf_menu_db_tools',
    ),
);
