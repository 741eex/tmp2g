<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Trigger_model extends BF_Model {

	protected $table_name = 'records_table';

	protected $set_created = true;
	protected $set_modified = true;

}