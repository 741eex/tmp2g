<h1>Drats!</h1>
<p><strong>The site is currently offline for maintenance.</strong>
    <?php if ($offlineReason) : ?>
</p>
<p><?php e($offlineReason); ?></p>
<p>
    <?php endif; ?>
    Please check back in a little while.
</p>
<p>Thanks for your understanding.</p>