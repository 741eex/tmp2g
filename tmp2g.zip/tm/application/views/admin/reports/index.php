<h1>This Page Intentionally Left Blank</h1>

<p>As of Bonfire <?php echo BONFIRE_VERSION ?>, this page has no default content.</p>

<p>This is your playground.</p>

<p>Make it home.</p>